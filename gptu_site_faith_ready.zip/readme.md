# gptu-site
Under construction terminal page for GPTU
# GPTU Auth + Contact System

## How to Use

1. Install dependencies:
```bash
npm install express bcrypt nodemailer express-session
